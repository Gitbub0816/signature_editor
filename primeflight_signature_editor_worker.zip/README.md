# PrimeFlight Signature Editor + Hosted Image Uploads

Deploys to the same Worker URL and adds:

- `/calebowen/` existing Caleb Owen hosted assets
- `/calebblaber/` Caleb Blaber hosted assets
- `/editor/` visual email signature editor
- `/u/<image-name>` uploaded hosted image URLs
- `/api/upload` image upload endpoint backed by Cloudflare KV
- `/api/list` recent uploaded image list

## Deploy

```bash
npm install
npx wrangler login
npx wrangler kv namespace create SIG_ASSETS
npx wrangler kv namespace create SIG_ASSETS --preview
```

Copy the returned namespace IDs into `wrangler.toml`, replacing:

```toml
id = "REPLACE_WITH_KV_NAMESPACE_ID"
preview_id = "REPLACE_WITH_PREVIEW_KV_NAMESPACE_ID"
```

Then deploy:

```bash
npm run deploy
```

Open:

```text
https://signature.caleb-owen2019.workers.dev/editor/
```

## Notes

Cloudflare KV is used because a normal static site cannot permanently host user-uploaded images by itself. KV image values are limited by Cloudflare's KV value size limit, so keep signature images compressed and reasonably small.
