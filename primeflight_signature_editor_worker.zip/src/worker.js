const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;
const ALLOWED_TYPES = new Set(['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

function safeName(input) {
  return String(input || 'signature-image')
    .trim()
    .toLowerCase()
    .replace(/\.[a-z0-9]+$/i, '')
    .replace(/[^a-z0-9-_]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80) || 'signature-image';
}

function extFromType(type) {
  if (type === 'image/png') return 'png';
  if (type === 'image/gif') return 'gif';
  if (type === 'image/webp') return 'webp';
  return 'jpg';
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store'
    }
  });
}

async function serveUpload(request, env) {
  if (!env.SIG_ASSETS) return json({ error: 'Missing Cloudflare KV binding: SIG_ASSETS' }, 500);
  const form = await request.formData();
  const file = form.get('image');
  const rawName = form.get('name');
  if (!file || typeof file === 'string') return json({ error: 'No image file was uploaded.' }, 400);
  if (!ALLOWED_TYPES.has(file.type)) return json({ error: 'Unsupported image type. Use JPG, PNG, GIF, or WEBP.' }, 400);
  if (file.size > MAX_UPLOAD_BYTES) return json({ error: 'Image is too large. Keep it under 5 MB.' }, 400);

  const ext = extFromType(file.type);
  const base = safeName(rawName || file.name || 'signature-image');
  const key = `uploads/${base}.${ext}`;
  const body = await file.arrayBuffer();
  await env.SIG_ASSETS.put(key, body, {
    metadata: {
      contentType: file.type,
      fileName: `${base}.${ext}`,
      uploadedAt: new Date().toISOString()
    }
  });

  const origin = new URL(request.url).origin;
  return json({
    ok: true,
    name: `${base}.${ext}`,
    path: `/u/${base}.${ext}`,
    url: `${origin}/u/${base}.${ext}`,
    contentType: file.type,
    size: file.size
  });
}

async function serveUploadedAsset(pathname, env) {
  if (!env.SIG_ASSETS) return new Response('Missing Cloudflare KV binding: SIG_ASSETS', { status: 500 });
  const name = decodeURIComponent(pathname.replace(/^\/u\//, ''));
  if (!/^[a-z0-9][a-z0-9-_]*\.(jpg|jpeg|png|gif|webp)$/i.test(name)) {
    return new Response('Invalid asset name', { status: 400 });
  }
  const key = `uploads/${name}`;
  const value = await env.SIG_ASSETS.getWithMetadata(key, { type: 'arrayBuffer' });
  if (!value || !value.value) return new Response('Not found', { status: 404 });
  return new Response(value.value, {
    headers: {
      'content-type': value.metadata?.contentType || 'application/octet-stream',
      'cache-control': 'public, max-age=31536000, immutable',
      'access-control-allow-origin': '*'
    }
  });
}

async function listUploads(request, env) {
  if (!env.SIG_ASSETS) return json({ error: 'Missing Cloudflare KV binding: SIG_ASSETS' }, 500);
  const origin = new URL(request.url).origin;
  const list = await env.SIG_ASSETS.list({ prefix: 'uploads/', limit: 50 });
  return json({
    uploads: list.keys.map(k => ({
      name: k.name.replace('uploads/', ''),
      url: `${origin}/u/${k.name.replace('uploads/', '')}`,
      uploadedAt: k.metadata?.uploadedAt || null,
      contentType: k.metadata?.contentType || null
    }))
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === 'POST' && url.pathname === '/api/upload') {
      return serveUpload(request, env);
    }
    if (request.method === 'GET' && url.pathname === '/api/list') {
      return listUploads(request, env);
    }
    if (request.method === 'GET' && url.pathname.startsWith('/u/')) {
      return serveUploadedAsset(url.pathname, env);
    }

    // Cloudflare static assets: /editor/, /calebowen/, /calebblaber/, etc.
    return env.ASSETS.fetch(request);
  }
};
